#!/usr/bin/env ruby

file = File.open('cleandf.csv', 'w')
file.puts "type;rps;tpr;median_tpr" #Type | Requests Per Second | Time Per Request | Median Time Per Request
ARGV.each do |arg|
    filetype = File.basename(arg).split('-')[0]
    rps = 0
    tpr = 0
    median_tpr = 0

    File.readlines(arg).each do |line|
        line.strip!
        if line.match /^Requests per second/
            rps = line.split(':')[1].strip.split(/\s+/)[0]
        elsif line.match /^Time per request/    
            tpr = line.split(':')[1].strip.split(/\s+/)[0]
        elsif line.match /^50%/    
            median_tpr = line.split(/\s+/)[1]
        end
    end

    file.puts "#{filetype};#{rps};#{tpr};#{median_tpr}"
end
