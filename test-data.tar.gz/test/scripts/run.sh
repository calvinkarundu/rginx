#!/usr/bin/env bash

if [ "$#" -ne 2 ]; then
    echo "Required <IP> <filename-prefix>"
    exit 1
fi

IP=$1
FILENAME=$2

mkdir -p results

MAX_REQUESTS=100   #TODO: Rampup 
MAX_CONCURRENCY=10 #TODO: RAMP up

ab -n ${MAX_REQUESTS} -c ${MAX_CONCURRENCY} http://${IP}:8080/jpg/${FILENAME}.jpg > results/jpg-${FILENAME}.txt
ab -n ${MAX_REQUESTS} -c ${MAX_CONCURRENCY} http://${IP}:8080/png/${FILENAME}.png > results/png-${FILENAME}.txt
ab -n ${MAX_REQUESTS} -c ${MAX_CONCURRENCY} http://${IP}:8080/gif/${FILENAME}.gif > results/gif-${FILENAME}.txt
ab -n ${MAX_REQUESTS} -c ${MAX_CONCURRENCY} http://${IP}:8080/svg/${FILENAME}.svg > results/svg-${FILENAME}.txt
ab -n ${MAX_REQUESTS} -c ${MAX_CONCURRENCY} http://${IP}:8080/css/${FILENAME}.css > results/css-${FILENAME}.txt
ab -n ${MAX_REQUESTS} -c ${MAX_CONCURRENCY} http://${IP}:8080/html/${FILENAME}.html > results/html-${FILENAME}.txt
ab -n ${MAX_REQUESTS} -c ${MAX_CONCURRENCY} http://${IP}:8080/js/${FILENAME}.js > results/js-${FILENAME}.txt
